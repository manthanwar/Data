
# Infant Common Illness Dataset (0–3 Years)

## Overview
This dataset contains 2,553 survey responses collected from parents of infants aged 0–3 years.
It includes demographic details, symptom reports, caregiver concerns, and final illness labels.
The dataset aims to support research in early detection and management of common childhood illnesses.

## Data Collection
- Collected via structured survey form responses.
- Location: Bangladesh.
- Timeframe: 2025.
- Target group: Infants aged 0–36 months.

## Files
- `dataset.csv`: Main dataset with 2,553 rows and 27 columns.
- `Data_Dictionary.xlsx`: Explanation of each column.
- `README.txt`: Dataset description and usage instructions.

## Usage
This dataset can be used for:
- Machine Learning model training for illness prediction.
- Public health research.
- Clinical decision support systems for pediatric healthcare.

## License
Released under **CC-BY 4.0** license.
Users may share and adapt the dataset with proper citation.

## Citation
Radoanul Arifen, & S.M. Meriyan Islam. (2025). Early Detection of Infant Common Illnesses (0–3 Years): Symptom-Based Dataset from Bangladesh [Data set]. Mendeley Data. https://doi.org/[DOI
will be generated after publishing]
